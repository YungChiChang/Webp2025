"""from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

class HelloApiView(APIView):
    def get(self, request):
        my_name = request.GET.get('name' , None)
        if my_name:
            retValue = {}
            retValue['data'] = "Hello" + my_name
            return Response(retVAlue, status=status.HTTP_200_OK)
        else:
            return Response(
                {"res":"parameter: name is None"},
                status=status.HTTP_400_BAD_REQUEST
            )

def myIndex(request):
    my_name = request.POST.get('name',"CGU")
    return HttpResponse("Hello "+my_name)

from rest_framework import status
from rest_framework.response import Response
from django.http import JsonResponse
from rest_framework.decorators import api_view
from django.core.serializers.json import DjangoJSONEncoder
import json
import logging

from .models import Post

logger = logging.getLogger('django')

Create your views here.
def myIndex(request):
    my_name = request.POST.get('name',"CGU")
    return HttpResponse("He
    
@api_view(['GET'])
def add_post(request):
    title = request.GET.get('title','')
    content = request.GET.get('content','')
    photo = request.GET.get('photo','')
    location = request.GET.get('location','')

    new_post = Post()
    new_post.title = title
    new_post.content = content
    new_post.photo = photo
    new_post.location = location
    new_post.save()
    logger.debug(" ************** myhello_api: " + title)
    if title:
        return Response({"data": title + " insert!"}, status=status.HTTP_200_OK)
    else:
        return Response(
            {"res":"parameter: name is None"},
            status=status.HTTP_400_BAD_REQUEST
        )

@api_view(['GET'])
def list_post(request):
    posts = Post.objects.all().values()
    return JsonResponse(list(posts), safe=False)
   return Response({"data":
    json.dumps(
        list(posts),
        sort_keys = True,
        indent = 1,
        cls = DjangoJSONEncoder)},
    status=status.HTTP_200_OK)
"""

"""from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from .models import Course

# 您现有的视图函数
def myhello_view(request):
    return HttpResponse("Hello World!")

# 课程列表 API
def courselist_view(request):
    # 获取课程数据
    # 如果数据库未迁移，使用硬编码数据
    try:
        courses = list(Course.objects.all().values('department', 'course_title', 'instructor'))
    except:
        # 硬编码的课程数据
        courses = [
                 {"開課單位": "資工系", "課程名稱": "物件導向軟體設計", "授課教師": "黃崇源"},
                 {"開課單位": "資工系", "課程名稱": "計算機網路實驗", "授課教師": "李春良"},
                 {"開課單位": "資工系", "課程名稱": "作業系統實務", "授課教師": "張哲維"},
                 {"開課單位": "資工系", "課程名稱": "生物統計", "授課教師": "陳光武"}
        ]
    
    # 返回 JSON 格式的课程列表
    return JsonResponse(courses, safe=False)


def addcourse_view(request):
    department = request.GET.get('department')
    course_title = request.GET.get('course_title')
    instructor = request.GET.get('instructor')
    
    if all([department, course_title, instructor]):
        try:
            data = {
                "開課單位": department,
                "課程名稱": course_title,
                "授課教師": instructor
            }
            return JsonResponse(data)
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})
    
    # 表单代码部分...
"""    
from django.http import JsonResponse
from .models import Course

# 存放課程資料的 list
course_list = []

def addcourse_view(request):
    department = request.GET.get('department')
    course_title = request.GET.get('course_title')
    instructor = request.GET.get('instructor')

    # 新增課程到 course_list (暫存)
    new_course = {
        "開課單位": department,
        "課程名稱": course_title,
        "授課教師": instructor
    }

    course_list.append(new_course)
    return JsonResponse(new_course, safe=False)

def courselist_view(request):
    return JsonResponse(course_list, safe=False)
