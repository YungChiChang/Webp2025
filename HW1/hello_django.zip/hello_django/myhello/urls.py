"""from django.urls import path
from . import views


urlpatterns = [
   # path('', views.some_view, name='some_view'),  
    path('add', views.add_post, name='add_post'),
    path('list', views.list_post, name='list_post'),
]



#from .views import add_initial_data

urlpatterns = [
    path('add_initial_data/', lambda request: (add_initial_data(), HttpResponse("Data Inserted!"))[1]),
]
"""

from django.contrib import admin
from django.urls import path
from . import views 

urlpatterns = [
    path('admin/', admin.site.urls),
    #path('myhello/', views.myhello_view),
    path('courselist/', views.courselist_view, name='courselist'),
    path('addcourse/', views.addcourse_view, name='addcourse'),
]

